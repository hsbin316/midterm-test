# 허성빈 201840235

화면에 어떤 과일을 좋아하나요 라는 문구를 h1으로 표현하였고   
사과, 오랜지, 바나나 버튼을 추가시켰다   

동작 :    
src\App.js
  Line 10:20:  '사과' is not defined   no-undef
  Line 13:20:  '오랜지' is not defined  no-undef
  Line 16:20:  '바나나' is not defined  no-undef
  와 같은 에러메시지가 나온다.